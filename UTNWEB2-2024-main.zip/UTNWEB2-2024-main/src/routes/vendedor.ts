import { Router } from "express";
import VendedoresController from "../controller/VendedoresController";

const routes = Router();

routes.get("", VendedoresController.getAll);
routes.get("/getOne/:id", VendedoresController.getOne);
routes.post("", VendedoresController.create);
routes.put("/:id", VendedoresController.update);
routes.delete("/:id", VendedoresController.delete);

export default routes;
