import { Router } from "express";
import CabeceraContoller from "../controller/CabeceraFacturaContoller";

const routes = Router();

routes.get("", CabeceraContoller.getAll);
routes.get("/getOne/:id", CabeceraContoller.getOne);
routes.post("", CabeceraContoller.create);
routes.put("/:id", CabeceraContoller.update);
routes.delete("/:id", CabeceraContoller.delete);

export default routes;
