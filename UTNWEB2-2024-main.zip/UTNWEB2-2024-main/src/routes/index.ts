import {Router} from "express"
import productos from "./productos";
import categoria from "./categorias";
import cabeceraFactura from "./cabeceraFactura";
import cliente from "./Cliente";


const routes= Router();

routes.use("/Productos", productos );
routes.use("/Categorias", categoria );
routes.use("/CabeceraFactura", cabeceraFactura );
routes.use("/Cliente", cliente );

export default routes;

