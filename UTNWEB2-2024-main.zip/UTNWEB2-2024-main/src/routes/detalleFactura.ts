import { Router } from "express";
import DetalleController from "../controller/DetalleController";

const routes = Router();

routes.get("", DetalleController.getAll);
routes.get("/getOne/:id", DetalleController.getOne);
routes.post("", DetalleController.create);
routes.put("/:id", DetalleController.update);
routes.delete("/:id", DetalleController.delete);

export default routes;
