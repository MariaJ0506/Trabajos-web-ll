import { Router } from "express";
import CategoriasController from "../controller/CategoriasController";

const routes = Router();

routes.get("", CategoriasController.getAll);
routes.get("/getOne/:id", CategoriasController.getOne);
routes.post("", CategoriasController.create); // Asegúrate de tener esta línea descomentada y configurada correctamente

export default routes; // Asegúrate de exportar las rutas por defecto

