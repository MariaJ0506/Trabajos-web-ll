import { Router } from "express";
import ClienteController from "../controller/ClienteContoller";

const routes = Router();

routes.get("", ClienteController.getAll);
routes.get("/getOne/:id", ClienteController.getOne);
routes.post("", ClienteController.create);
routes.put("/:id", ClienteController.update);
routes.delete("/:id", ClienteController.delete);

export default routes;
