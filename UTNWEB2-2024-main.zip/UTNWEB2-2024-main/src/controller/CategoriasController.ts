import { Request, Response } from "express";
import { AppDataSource } from "../data-source";
import { Categoria } from "../entity/Categoria";

class CategoriasController {
    static getAll = async (req: Request, res: Response) => {
        try {
            const repo = AppDataSource.getRepository(Categoria);
            const lista = await repo.find({ where: { estado: true }, relations: { Productos: true } });

            if (lista.length == 0) {
                return res.status(404).json({ message: "No hay datos registrados." });
            }
            return res.status(200).json(lista);
        } catch (error) {
            return res.status(400).json({ message: "Error al acceder a la base de datos." });
        }
    }

    static getOne = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params['id']);

            if (!id) {
                return res.status(400).json({ message: "Debe indicar el ID" });
            }

            const repo = AppDataSource.getRepository(Categoria);

            try {
                const categoria = await repo.findOneOrFail({ where: { id, estado: true }, relations: { Productos: true } });
                return res.status(200).json(categoria);
            } catch (error) {
                return res.status(404).json({ message: "La categoría con el ID indicado no existe en la base de datos." });
            }
        } catch (error) {
            return res.status(404).json({ message: "Error al guardar la categoría." });
        }
    }

    static create = async (req: Request, res: Response) => {
        try {
            // Extraer datos del cuerpo de la solicitud
            const { nombre, descripcion, estado } = req.body;

            // Validar los datos recibidos
            if (!nombre || !descripcion || estado === undefined) {
                return res.status(400).json({ message: "Todos los campos son requeridos: nombre, descripcion, estado." });
            }

            // Crear una nueva instancia de la categoría
            const nuevaCategoria = new Categoria();
            nuevaCategoria.nombre = nombre;
            nuevaCategoria.descripcion = descripcion;
            nuevaCategoria.estado = estado;

            // Guardar la categoría en la base de datos
            const repo = AppDataSource.getRepository(Categoria);
            const categoriaGuardada = await repo.save(nuevaCategoria);

            // Responder con la categoría creada
            return res.status(201).json(categoriaGuardada);
        } catch (error) {
            return res.status(400).json({ message: "Error al crear la categoría.", error: error.message });
        }
    }
}

export default CategoriasController;
