import { Request, Response } from "express";
import { AppDataSource } from "../data-source";
import { CabeceraFactura } from "../entity/CabeceraFactura";
import { Cliente } from "../entity/Cliente";
import { Vendedor } from "../entity/Vendedor";
import { validate } from "class-validator";

class CabeceraFacturaController {
    static getAll = async (req: Request, res: Response) => {
        try {
            const repo = AppDataSource.getRepository(CabeceraFactura);
            const listaCabeceraFactura = await repo.find({ where: { estado: true }, relations: ["cliente", "vendedor"] });
            if (listaCabeceraFactura.length === 0) {
                return res.status(404).json({ message: "No hay datos registrados." });
            }
            return res.status(200).json(listaCabeceraFactura);
        } catch (error) {
            return res.status(400).json({ message: "Error al acceder a la base de datos." });
        }
    }

    static getOne = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params.id);
            if (!id) {
                return res.status(400).json({ message: "Debe indicar el ID" });
            }
            const repo = AppDataSource.getRepository(CabeceraFactura);
            try {
                const cabeceraFactura = await repo.findOneOrFail({ where: { numero_factura: id, estado: true }, relations: ["cliente", "vendedor"] });
                return res.status(200).json(cabeceraFactura);
            } catch (error) {
                return res.status(404).json({ message: "La cabecera de la factura con el ID indicado no existe en la base de datos." });
            }
        } catch (error) {
            return res.status(404).json({ message: "Error al acceder a la base de datos." });
        }
    }

    static create = async (req: Request, res: Response) => {
        const { numero_factura, fecha_factura, subtotal, iva, total, codigo_cliente, codigo_vendedor } = req.body;
        const repoCabeceraFactura = AppDataSource.getRepository(CabeceraFactura);

        try {
            let cabeceraFactura = await repoCabeceraFactura.findOne({ where: { numero_factura } });
            if (cabeceraFactura) {
                return res.status(400).json({ message: "Esa cabecera de factura ya existe en la base de datos." });
            }

            cabeceraFactura = new CabeceraFactura();
            cabeceraFactura.numero_factura = numero_factura;
            cabeceraFactura.fecha_factura = fecha_factura;
            cabeceraFactura.subtotal = subtotal;
            cabeceraFactura.iva = iva;
            cabeceraFactura.total = total;
            cabeceraFactura.estado = true;

            // Validar cliente
            const repoCliente = AppDataSource.getRepository(Cliente);
            let cliente;
            try {
                cliente = await repoCliente.findOneOrFail({ where: { codigo_cliente } });
            } catch (ex) {
                return res.status(400).json({ message: "No existe el cliente." });
            }
            cabeceraFactura.cliente = cliente;

            // Validar vendedor
            const repoVendedor = AppDataSource.getRepository(Vendedor);
            let vendedor;
            try {
                vendedor = await repoVendedor.findOneOrFail({ where: { codigo_vendedor } });
            } catch (ex) {
                return res.status(400).json({ message: "No existe el vendedor." });
            }
            cabeceraFactura.vendedor = vendedor;

            const errors = await validate(cabeceraFactura, { validationError: { target: false, value: false } });
            if (errors.length > 0) {
                return res.status(400).json(errors);
            }

            await repoCabeceraFactura.save(cabeceraFactura);
            return res.status(200).json("Cabecera de factura guardada correctamente.");
        } catch (error) {
            return res.status(400).json({ message: "Error al guardar." });
        }
    }

    static update = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params.id);
            const { fecha_factura, subtotal, iva, total, codigo_cliente, codigo_vendedor } = req.body;
            const repo = AppDataSource.getRepository(CabeceraFactura);
            let cabeceraFactura;
            try {
                cabeceraFactura = await repo.findOneOrFail({ where: { numero_factura: id } });
            } catch (error) {
                return res.status(404).json({ message: "La cabecera de factura con el ID indicado no existe en la base de datos." });
            }

            cabeceraFactura.fecha_factura = fecha_factura;
            cabeceraFactura.subtotal = subtotal;
            cabeceraFactura.iva = iva;
            cabeceraFactura.total = total;

            // Validar cliente
            const repoCliente = AppDataSource.getRepository(Cliente);
            let cliente;
            try {
                cliente = await repoCliente.findOneOrFail({ where: { codigo_cliente } });
            } catch (ex) {
                return res.status(400).json({ message: "No existe el cliente." });
            }
            cabeceraFactura.cliente = cliente;

            // Validar vendedor
            const repoVendedor = AppDataSource.getRepository(Vendedor);
            let vendedor;
            try {
                vendedor = await repoVendedor.findOneOrFail({ where: { codigo_vendedor } });
            } catch (ex) {
                return res.status(400).json({ message: "No existe el vendedor." });
            }
            cabeceraFactura.vendedor = vendedor;

            const errors = await validate(cabeceraFactura, { validationError: { target: false, value: false } });
            if (errors.length > 0) {
                return res.status(400).json(errors);
            }

            await repo.save(cabeceraFactura);
            return res.status(200).json({ message: "La cabecera de la factura ha sido modificada." });
        } catch (error) {
            return res.status(404).json({ message: "Error al actualizar la cabecera de la factura." });
        }
    }

    static delete = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params.id);
            if (!id) {
                return res.status(400).json({ message: "Debe indicar el ID" });
            }
            const repo = AppDataSource.getRepository(CabeceraFactura);
            let cabeceraFactura;
            try {
                cabeceraFactura = await repo.findOneOrFail({ where: { numero_factura: id } });
            } catch (error) {
                return res.status(404).json({ message: "La cabecera de la factura con el ID indicado no existe en la base de datos." });
            }
            cabeceraFactura.estado = false;
            await repo.save(cabeceraFactura);
            return res.status(200).json({ message: "La cabecera de la factura ha sido eliminada." });
        } catch (error) {
            return res.status(404).json({ message: "Error al eliminar la cabecera de la factura." });
        }
    }
}

export default CabeceraFacturaController;
