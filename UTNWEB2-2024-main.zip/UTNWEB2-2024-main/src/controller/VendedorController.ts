import { Request, Response } from "express";
import { AppDataSource } from "../data-source";
import { Vendedor } from "../entity/Vendedor";
import { validate } from "class-validator";

class VendedorController {
    static getAll = async (req: Request, res: Response) => {
        try {
            const repo = AppDataSource.getRepository(Vendedor);
            const listaVendedores = await repo.find({ where: { estado: true } });
            if (listaVendedores.length === 0) {
                return res.status(404).json({ message: "No hay datos registrados." });
            }
            return res.status(200).json(listaVendedores);
        } catch (error) {
            return res.status(400).json({ message: "Error al acceder a la base de datos." });
        }
    }

    static getOne = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params.id);
            if (!id) {
                return res.status(400).json({ message: "Debe indicar el ID" });
            }
            const repo = AppDataSource.getRepository(Vendedor);
            try {
                const vendedor = await repo.findOneOrFail({ where: { codigo_vendedor: id, estado: true } });
                return res.status(200).json(vendedor);
            } catch (error) {
                return res.status(404).json({ message: "El vendedor con el ID indicado no existe en la base de datos." });
            }
        } catch (error) {
            return res.status(404).json({ message: "Error al acceder a la base de datos." });
        }
    }

    static create = async (req: Request, res: Response) => {
        const { codigo_vendedor, nombres_vendedor, apellido_vendedor, telefono_vendedor, email_vendedor, zona_vendedor } = req.body;
        const repoVendedor = AppDataSource.getRepository(Vendedor);

        try {
            let vendedor = await repoVendedor.findOne({ where: { codigo_vendedor } });
            if (vendedor) {
                return res.status(400).json({ message: "Ese vendedor ya existe en la base de datos." });
            }

            vendedor = new Vendedor();
            vendedor.codigo_vendedor = codigo_vendedor;
            vendedor.nombres_vendedor = nombres_vendedor;
            vendedor.apellido_vendedor = apellido_vendedor;
            vendedor.telefono_vendedor = telefono_vendedor;
            vendedor.email_vendedor = email_vendedor;
            vendedor.zona_vendedor = zona_vendedor;
            vendedor.estado = true;

            const errors = await validate(vendedor, { validationError: { target: false, value: false } });
            if (errors.length > 0) {
                return res.status(400).json(errors);
            }

            await repoVendedor.save(vendedor);
            return res.status(200).json("Vendedor guardado correctamente.");
        } catch (error) {
            return res.status(400).json({ message: "Error al guardar." });
        }
    }

    static update = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params.id);
            const { nombres_vendedor, apellido_vendedor, telefono_vendedor, email_vendedor, zona_vendedor } = req.body;
            const repo = AppDataSource.getRepository(Vendedor);
            let vendedor;
            try {
                vendedor = await repo.findOneOrFail({ where: { codigo_vendedor: id } });
            } catch (error) {
                return res.status(404).json({ message: "El vendedor con el ID indicado no existe en la base de datos." });
            }

            vendedor.nombres_vendedor = nombres_vendedor;
            vendedor.apellido_vendedor = apellido_vendedor;
            vendedor.telefono_vendedor = telefono_vendedor;
            vendedor.email_vendedor = email_vendedor;
            vendedor.zona_vendedor = zona_vendedor;

            const errors = await validate(vendedor, { validationError: { target: false, value: false } });
            if (errors.length > 0) {
                return res.status(400).json(errors);
            }

            await repo.save(vendedor);
            return res.status(200).json({ message: "El vendedor ha sido modificado." });
        } catch (error) {
            return res.status(404).json({ message: "Error al actualizar el vendedor." });
        }
    }

    static delete = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params.id);
            if (!id) {
                return res.status(400).json({ message: "Debe indicar el ID" });
            }
            const repo = AppDataSource.getRepository(Vendedor);
            let vendedor;
            try {
                vendedor = await repo.findOneOrFail({ where: { codigo_vendedor: id } });
            } catch (error) {
                return res.status(404).json({ message: "El vendedor con el ID indicado no existe en la base de datos." });
            }
            vendedor.estado = false;
            await repo.save(vendedor);
            return res.status(200).json({ message: "El vendedor ha sido eliminado." });
        } catch (error) {
            return res.status(404).json({ message: "Error al eliminar el vendedor." });
        }
    }
}

export default VendedorController;
