import { Request, Response } from "express";
import { AppDataSource } from "../data-source";
import { Proveedor } from "../entity/Proveedor";
import { validate } from "class-validator";

class ProveedorController {
    static getAll = async (req: Request, res: Response) => {
        try {
            const repo = AppDataSource.getRepository(Proveedor);
            const listaProveedores = await repo.find({ where: { estado: true } });
            if (listaProveedores.length == 0) {
                return res.status(404).json({ message: "No hay datos registrados." });
            }
            return res.status(200).json(listaProveedores);
        } catch (error) {
            return res.status(400).json({ message: "Error al acceder a la base de datos." });
        }
    }

    static getOne = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params['id']);
            if (!id) {
                return res.status(400).json({ message: "Debe indicar el ID" });
            }
            const repo = AppDataSource.getRepository(Proveedor);
            try {
                const proveedor = await repo.findOneOrFail({ where: { codigo_proveedor: id, estado: true } });
                return res.status(200).json(proveedor);
            } catch (error) {
                return res.status(404).json({ message: "El proveedor con el ID indicado no existe en la base de datos." });
            }
        } catch (error) {
            return res.status(404).json({ message: "Error al acceder a la base de datos." });
        }
    }

    static create = async (req: Request, res: Response) => {
        const { codigo_proveedor, nombres_proveedor, direccion_proveedor, telefono_proveedor } = req.body;
        const repoProveedor = AppDataSource.getRepository(Proveedor);

        try {
            let proveedor = await repoProveedor.findOne({ where: { codigo_proveedor } });
            if (proveedor) {
                return res.status(400).json({ message: "Ese proveedor ya existe en la base de datos." });
            }

            proveedor = new Proveedor();
            proveedor.codigo_proveedor = codigo_proveedor;
            proveedor.nombres_proveedor = nombres_proveedor;
            proveedor.direccion_proveedor = direccion_proveedor;
            proveedor.telefono_proveedor = telefono_proveedor;
            proveedor.estado = true;

            const errors = await validate(proveedor, { validationError: { target: false, value: false } });
            if (errors.length > 0) {
                return res.status(400).json(errors);
            }

            await repoProveedor.save(proveedor);
            return res.status(200).json("Proveedor guardado correctamente.");
        } catch (error) {
            return res.status(400).json({ message: "Error al guardar." });
        }
    }

    static update = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params['id']);
            const { nombres_proveedor, direccion_proveedor, telefono_proveedor } = req.body;
            const repo = AppDataSource.getRepository(Proveedor);
            let proveedor;
            try {
                proveedor = await repo.findOneOrFail({ where: { codigo_proveedor: id } });
            } catch (error) {
                return res.status(404).json({ message: "El proveedor con el ID indicado no existe en la base de datos." });
            }

            proveedor.nombres_proveedor = nombres_proveedor;
            proveedor.direccion_proveedor = direccion_proveedor;
            proveedor.telefono_proveedor = telefono_proveedor;

            const errors = await validate(proveedor, { validationError: { target: false, value: false } });
            if (errors.length > 0) {
                return res.status(400).json(errors);
            }

            await repo.save(proveedor);
            return res.status(200).json({ message: "El proveedor ha sido modificado." });
        } catch (error) {
            return res.status(404).json({ message: "Error al actualizar el proveedor." });
        }
    }

    static delete = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params['id']);
            if (!id) {
                return res.status(400).json({ message: "Debe indicar el ID" });
            }
            const repo = AppDataSource.getRepository(Proveedor);
            let proveedor;
            try {
                proveedor = await repo.findOneOrFail({ where: { codigo_proveedor: id } });
            } catch (error) {
                return res.status(404).json({ message: "El proveedor con el ID indicado no existe en la base de datos." });
            }
            proveedor.estado = false;
            await repo.save(proveedor);
            return res.status(200).json({ message: "El proveedor ha sido eliminado." });
        } catch (error) {
            return res.status(404).json({ message: "Error al eliminar el proveedor." });
        }
    }
}

export default ProveedorController;
