import { Request, Response } from "express";
import { AppDataSource } from "../data-source";
import { DetalleFactura } from "../entity/DetalleFactura";
import { CabeceraFactura } from "../entity/CabeceraFactura";
import { Productos } from "../entity/Productos";
import { validate } from "class-validator";

class DetalleController {
    static getAll = async (req: Request, res: Response) => {
        try {
            const repo = AppDataSource.getRepository(DetalleFactura);
            const listaDetalleFacturas = await repo.find({ where: { estado: true }, relations: ["cabeceraFactura", "producto"] });
            if (listaDetalleFacturas.length === 0) {
                return res.status(404).json({ message: "No hay datos registrados." });
            }
            return res.status(200).json(listaDetalleFacturas);
        } catch (error) {
            return res.status(400).json({ message: "Error al acceder a la base de datos." });
        }
    }

    static getOne = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params.id);
            if (!id) {
                return res.status(400).json({ message: "Debe indicar el ID" });
            }
            const repo = AppDataSource.getRepository(DetalleFactura);
            try {
                const detalleFactura = await repo.findOneOrFail({ where: { numero_detalle: id, estado: true }, relations: ["cabeceraFactura", "producto"] });
                return res.status(200).json(detalleFactura);
            } catch (error) {
                return res.status(404).json({ message: "El detalle de la factura con el ID indicado no existe en la base de datos." });
            }
        } catch (error) {
            return res.status(404).json({ message: "Error al acceder a la base de datos." });
        }
    }

    static create = async (req: Request, res: Response) => {
        const { numero_detalle, cantidad, precio, codigo_producto, numero_factura } = req.body;
        const repoDetalleFactura = AppDataSource.getRepository(DetalleFactura);

        try {
            let detalleFactura = await repoDetalleFactura.findOne({ where: { numero_detalle } });
            if (detalleFactura) {
                return res.status(400).json({ message: "Ese detalle de factura ya existe en la base de datos." });
            }

            detalleFactura = new DetalleFactura();
            detalleFactura.numero_detalle = numero_detalle;
            detalleFactura.cantidad = cantidad;
            detalleFactura.precio = precio;
            detalleFactura.estado = true;

            // Validar producto
            const repoProducto = AppDataSource.getRepository(Productos);
            let producto;
            try {
                producto = await repoProducto.findOneOrFail({ where: { codigo_producto } });
            } catch (ex) {
                return res.status(400).json({ message: "No existe el producto." });
            }
            detalleFactura.producto = producto;

            // Validar cabecera de factura
            const repoCabeceraFactura = AppDataSource.getRepository(CabeceraFactura);
            let cabeceraFactura;
            try {
                cabeceraFactura = await repoCabeceraFactura.findOneOrFail({ where: { numero_factura } });
            } catch (ex) {
                return res.status(400).json({ message: "No existe la cabecera de la factura." });
            }
            detalleFactura.cabeceraFactura = cabeceraFactura;

            const errors = await validate(detalleFactura, { validationError: { target: false, value: false } });
            if (errors.length > 0) {
                return res.status(400).json(errors);
            }

            await repoDetalleFactura.save(detalleFactura);
            return res.status(200).json("Detalle de factura guardado correctamente.");
        } catch (error) {
            return res.status(400).json({ message: "Error al guardar." });
        }
    }

    static update = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params.id);
            const { cantidad, precio, codigo_producto, numero_factura } = req.body;
            const repo = AppDataSource.getRepository(DetalleFactura);
            let detalleFactura;
            try {
                detalleFactura = await repo.findOneOrFail({ where: { numero_detalle: id } });
            } catch (error) {
                return res.status(404).json({ message: "El detalle de la factura con el ID indicado no existe en la base de datos." });
            }

            detalleFactura.cantidad = cantidad;
            detalleFactura.precio = precio;

            // Validar producto
            const repoProducto = AppDataSource.getRepository(Productos);
            let producto;
            try {
                producto = await repoProducto.findOneOrFail({ where: { codigo_producto } });
            } catch (ex) {
                return res.status(400).json({ message: "No existe el producto." });
            }
            detalleFactura.producto = producto;

            // Validar cabecera de factura
            const repoCabeceraFactura = AppDataSource.getRepository(CabeceraFactura);
            let cabeceraFactura;
            try {
                cabeceraFactura = await repoCabeceraFactura.findOneOrFail({ where: { numero_factura } });
            } catch (ex) {
                return res.status(400).json({ message: "No existe la cabecera de la factura." });
            }
            detalleFactura.cabeceraFactura = cabeceraFactura;

            const errors = await validate(detalleFactura, { validationError: { target: false, value: false } });
            if (errors.length > 0) {
                return res.status(400).json(errors);
            }

            await repo.save(detalleFactura);
            return res.status(200).json({ message: "El detalle de la factura ha sido modificado." });
        } catch (error) {
            return res.status(404).json({ message: "Error al actualizar el detalle de la factura." });
        }
    }

    static delete = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params.id);
            if (!id) {
                return res.status(400).json({ message: "Debe indicar el ID" });
            }
            const repo = AppDataSource.getRepository(DetalleFactura);
            let detalleFactura;
            try {
                detalleFactura = await repo.findOneOrFail({ where: { numero_detalle: id } });
            } catch (error) {
                return res.status(404).json({ message: "El detalle de la factura con el ID indicado no existe en la base de datos." });
            }
            detalleFactura.estado = false;
            await repo.save(detalleFactura);
            return res.status(200).json({ message: "El detalle de la factura ha sido eliminado." });
        } catch (error) {
            return res.status(404).json({ message: "Error al eliminar el detalle de la factura." });
        }
    }
}

export default DetalleController;
