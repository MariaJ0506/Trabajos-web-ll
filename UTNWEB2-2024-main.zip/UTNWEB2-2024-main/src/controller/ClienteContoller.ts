import { Request, Response } from "express";
import { AppDataSource } from "../data-source";
import { Cliente } from "../entity/Cliente";
import { validate } from "class-validator";

class ClienteController {
    static getAll = async (req: Request, res: Response) => {
        try {
            const repo = AppDataSource.getRepository(Cliente);
            const listaClientes = await repo.find({ where: { estado: true } });
            if (listaClientes.length == 0) {
                return res.status(404).json({ message: "No hay datos registrados." });
            }
            return res.status(200).json(listaClientes);
        } catch (error) {
            return res.status(400).json({ message: "Error al acceder a la base de datos." });
        }
    }

    static getOne = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params['id']);
            if (!id) {
                return res.status(400).json({ message: "Debe indicar el ID" });
            }
            const repo = AppDataSource.getRepository(Cliente);
            try {
                const cliente = await repo.findOneOrFail({ where: { codigo_cliente: id, estado: true } });
                return res.status(200).json(cliente);
            } catch (error) {
                return res.status(404).json({ message: "El cliente con el ID indicado no existe en la base de datos." });
            }
        } catch (error) {
            return res.status(404).json({ message: "Error al acceder a la base de datos." });
        }
    }

    static create = async (req: Request, res: Response) => {
        const { codigo_cliente, nombres_cliente, apellidos_cliente, direccion_cliente, telefono_cliente, ciudad_cliente, email_cliente } = req.body;
        const repoCliente = AppDataSource.getRepository(Cliente);

        try {
            let cliente = await repoCliente.findOne({ where: { codigo_cliente } });
            if (cliente) {
                return res.status(400).json({ message: "Ese cliente ya existe en la base de datos." });
            }

            cliente = new Cliente();
            cliente.codigo_cliente = codigo_cliente;
            cliente.nombres_cliente = nombres_cliente;
            cliente.apellidos_cliente = apellidos_cliente;
            cliente.direccion_cliente = direccion_cliente;
            cliente.telefono_cliente = telefono_cliente;
            cliente.ciudad_cliente = ciudad_cliente;
            cliente.email_cliente = email_cliente;
            cliente.estado = true;

            const errors = await validate(cliente, { validationError: { target: false, value: false } });
            if (errors.length > 0) {
                return res.status(400).json(errors);
            }

            await repoCliente.save(cliente);
            return res.status(200).json("Cliente guardado correctamente.");
        } catch (error) {
            return res.status(400).json({ message: "Error al guardar." });
        }
    }

    static update = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params['id']);
            const { nombres_cliente, apellidos_cliente, direccion_cliente, telefono_cliente, ciudad_cliente, email_cliente } = req.body;
            const repo = AppDataSource.getRepository(Cliente);
            let cliente;
            try {
                cliente = await repo.findOneOrFail({ where: { codigo_cliente: id } });
            } catch (error) {
                return res.status(404).json({ message: "El cliente con el ID indicado no existe en la base de datos." });
            }

            cliente.nombres_cliente = nombres_cliente;
            cliente.apellidos_cliente = apellidos_cliente;
            cliente.direccion_cliente = direccion_cliente;
            cliente.telefono_cliente = telefono_cliente;
            cliente.ciudad_cliente = ciudad_cliente;
            cliente.email_cliente = email_cliente;

            const errors = await validate(cliente, { validationError: { target: false, value: false } });
            if (errors.length > 0) {
                return res.status(400).json(errors);
            }

            await repo.save(cliente);
            return res.status(200).json({ message: "El cliente ha sido modificado." });
        } catch (error) {
            return res.status(404).json({ message: "Error al actualizar el cliente." });
        }
    }

    static delete = async (req: Request, res: Response) => {
        try {
            const id = parseInt(req.params['id']);
            if (!id) {
                return res.status(400).json({ message: "Debe indicar el ID" });
            }
            const repo = AppDataSource.getRepository(Cliente);
            let cliente;
            try {
                cliente = await repo.findOneOrFail({ where: { codigo_cliente: id } });
            } catch (error) {
                return res.status(404).json({ message: "El cliente con el ID indicado no existe en la base de datos." });
            }
            cliente.estado = false;
            await repo.save(cliente);
            return res.status(200).json({ message: "El cliente ha sido eliminado." });
        } catch (error) {
            return res.status(404).json({ message: "Error al eliminar el cliente." });
        }
    }
}

export default ClienteController;
