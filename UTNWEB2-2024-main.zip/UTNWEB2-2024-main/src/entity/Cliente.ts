import { IsNotEmpty, MaxLength, IsPhoneNumber } from "class-validator";
import { Column, Entity, PrimaryColumn } from "typeorm";

@Entity()
export class Cliente {
    @PrimaryColumn()
    @IsNotEmpty()
    ruc_cliente: string;

    @Column({ length: 50 })
    @MaxLength(50)
    @IsNotEmpty()
    nombres_cliente: string;

    @Column({ length: 50 })
    @MaxLength(50)
    @IsNotEmpty()
    apellidos_cliente: string;

    @Column({ length: 100 })
    @MaxLength(100)
    direccion_cliente: string;

    @Column({ length: 15 })
    @MaxLength(15)
    @IsPhoneNumber(null)
    telefono_cliente: string;
    codigo_cliente: any;
    ciudad_cliente: any;
    email_cliente: any;
    estado: boolean;
}
