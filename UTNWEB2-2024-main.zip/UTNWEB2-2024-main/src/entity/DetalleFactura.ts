import { IsNotEmpty, IsNumber, IsPositive } from "class-validator";
import { Column, Entity, PrimaryGeneratedColumn, ManyToOne } from "typeorm";
import { Productos } from "./Productos";
import { CabeceraFactura } from "./CabeceraFactura";

@Entity()
export class DetalleFactura {
    @PrimaryGeneratedColumn()
    @IsNotEmpty()
    numero: number;

    @Column()
    @IsNumber()
    @IsPositive()
    @IsNotEmpty()
    cantidad: number;

    @ManyToOne(() => Productos)
    @IsNotEmpty()
    codigo_producto: Productos;

    @ManyToOne(() => CabeceraFactura)
    @IsNotEmpty()
    cabeceraFactura: CabeceraFactura;
    numero_detalle: any;
    precio: any;
    estado: boolean;
    producto: any;
}
