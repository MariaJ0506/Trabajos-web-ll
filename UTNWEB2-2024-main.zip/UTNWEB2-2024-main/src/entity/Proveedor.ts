import { IsNotEmpty, MaxLength, IsPhoneNumber } from "class-validator";
import { Column, Entity, PrimaryColumn, OneToMany } from "typeorm";
import { Productos } from "./Productos";

@Entity()
export class Proveedor {
    @PrimaryColumn()
    @IsNotEmpty()
    codigo_proveedor: number;

    @Column({ length: 50 })
    @MaxLength(50)
    @IsNotEmpty()
    nombres_proveedor: string;

    @Column({ length: 50 })
    @MaxLength(50)
    @IsNotEmpty()
    apellidos_proveedor: string;

    @Column({ length: 100 })
    @MaxLength(100)
    direccion_proveedor: string;

    @Column({ length: 50 })
    @MaxLength(50)
    provincia_proveedor: string;

    @Column({ length: 15 })
    @MaxLength(15)
    @IsPhoneNumber(null)
    telefono_proveedor: string;

    @OneToMany(() => Productos, producto => producto.proveedor)
    productos: Productos[];
    estado: boolean;
}
