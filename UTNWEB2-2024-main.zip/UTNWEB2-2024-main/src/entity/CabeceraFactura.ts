import { IsNotEmpty, IsDate } from "class-validator";
import { Column, Entity, PrimaryGeneratedColumn, ManyToOne } from "typeorm";
import { Cliente } from "./Cliente";
import { Vendedor } from "./Vendedor";

@Entity()
export class CabeceraFactura {
    @PrimaryGeneratedColumn()
    @IsNotEmpty()
    numero: number;

    @Column()
    @IsDate()
    @IsNotEmpty()
    fecha: Date;

    @ManyToOne(() => Cliente)
    @IsNotEmpty()
    ruc_cliente: Cliente;

    @ManyToOne(() => Vendedor)
    @IsNotEmpty()
    codigo_vendedor: Vendedor;
    numero_factura: any;
    fecha_factura: any;
    subtotal: any;
    iva: any;
    total: any;
    estado: boolean;
    cliente: any;
    vendedor: any;
}

