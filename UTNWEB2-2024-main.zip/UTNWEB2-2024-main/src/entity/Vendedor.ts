import { IsNotEmpty, MaxLength, IsPhoneNumber } from "class-validator";
import { Column, Entity, PrimaryColumn } from "typeorm";

@Entity()
export class Vendedor {
    [x: string]: any;
    @PrimaryColumn()
    @IsNotEmpty()
    codigo_vendedor: number;

    @Column({ length: 50 })
    @MaxLength(50)
    @IsNotEmpty()
    nombres_vendedor: string;

    @Column({ length: 50 })
    @MaxLength(50)
    @IsNotEmpty()
    apellidos_vendedor: string;

    @Column({ length: 100 })
    @MaxLength(100)
    direccion_vendedor: string;

    @Column({ length: 15 })
    @MaxLength(15)
    @IsPhoneNumber(null)
    telefono_vendedor: string;

    @Column({ length: 15 })
    @MaxLength(15)
    @IsPhoneNumber(null)
    celular_vendedor: string;
}
